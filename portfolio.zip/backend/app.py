from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os

# In production, serve built frontend from backend/static
app = Flask(__name__, static_folder='static', static_url_path='/')
CORS(app)

@app.route('/api/contact', methods=['POST'])
def contact():
    data = request.json or {}
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    # In production, replace print with sending email or saving to DB
    print(f"Contact from {name} <{email}>: {message}")
    return jsonify({'ok': True}), 200

# Serve the frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != '' and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    index_path = os.path.join(app.static_folder, 'index.html')
    if os.path.exists(index_path):
        return send_from_directory(app.static_folder, 'index.html')
    return 'Frontend not built. Run `npm run build` and copy dist to backend/static', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
