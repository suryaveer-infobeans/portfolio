# Thakur Suryaveer — Portfolio (React + Flask)

This is a runnable portfolio scaffold (React + Tailwind CSS frontend, Flask backend).
Your resume PDF is included in `/public/Thakur_Suryaveer_Resume.pdf`.

## Run locally (development)

### 1) Frontend
```bash
npm install
npm run dev
```
Open http://localhost:5173

### 2) Backend
```bash
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r backend/requirements.txt
python backend/app.py
```
Open http://localhost:5000

The frontend dev server proxies `/api` to `http://localhost:5000`.

## Production build
```bash
npm run build
# copy dist contents into backend/static
cp -r dist/* backend/static/
# then run backend
python backend/app.py
```

## Notes
- The contact form posts to `/api/contact`, which currently just prints to console.
- Replace placeholder project descriptions or add screenshots in `public/` as needed.
