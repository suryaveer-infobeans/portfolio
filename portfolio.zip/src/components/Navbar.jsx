import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar(){
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="font-bold text-xl">Thakur Suryaveer</Link>
        <nav className="space-x-6 hidden md:block">
          <Link to="/projects" className="hover:underline">Projects</Link>
          <Link to="/about" className="hover:underline">About</Link>
          <Link to="/contact" className="hover:underline">Contact</Link>
          <a href="/public/Thakur_Suryaveer_Resume.pdf" target="_blank" rel="noreferrer" className="hover:underline">Resume</a>
        </nav>
        <div className="md:hidden">{/* mobile toggle placeholder */}</div>
      </div>
    </header>
  )
}
