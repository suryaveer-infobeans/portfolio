import React from 'react'

const projects = [
  {
    "title": "Weather Insights Data Pipeline",
    "period": "Apr 2025 - Jul 2025",
    "technologies": ["AWS", "Snowflake", "Django", "Lambda", "CloudWatch"],
    "description": "Built a scalable pipeline to fetch and process weather data into Snowflake with AWS automation and analytics.",
    "bullets": [
      "ETL pipeline to ingest and transform weather data",
      "Reporting UI built with Django",
      "Automated scheduling with AWS Lambda & CloudWatch"
    ]
  },
  {
    "title": "POC Load Balancer & Queue Runner",
    "period": "Aug 2025",
    "technologies": ["Flask", "FastAPI", "MySQL", "Apache Bench"],
    "description": "Developed proof-of-concept load balancer with FIFO queue and concurrency control.",
    "bullets": [
      "Implemented FIFO + semaphore concurrency control",
      "Dashboard monitoring with Flask",
      "Stress tested using Apache Bench"
    ]
  },
  {
    "title": "Smart Interview Assessment",
    "period": "Jul 2024 - Dec 2024",
    "technologies": ["OpenCV", "Whisper", "Django", "Flask"],
    "description": "AI-powered tool for analyzing interviewees’ facial expressions and speech confidence.",
    "bullets": [
      "Face detection with OpenCV",
      "Speech-to-text & tone analysis with Whisper",
      "Visualization dashboards with Django & Flask"
    ]
  },
  {
    "title": "AI Career Path Development Program",
    "period": "2024",
    "technologies": ["Python", "LLMs", "Flask", "React"],
    "description": "Developed an AI-based career path program to help underprivileged children identify suitable career paths.",
    "bullets": [
      "Trained GPT-like models on educational datasets",
      "Designed Flask backend with React frontend",
      "Career recommendations based on interests & knowledge"
    ]
  },
  {
    "title": "Automation Tools & Backend Systems",
    "period": "2019 - 2024",
    "technologies": ["Python", "Django", "Flask", "MySQL", "Oracle"],
    "description": "Developed backend services and automation workflows for enterprise systems.",
    "bullets": [
      "REST APIs and automation scripts in Python",
      "Database triggers and log parsing",
      "CI/CD setup with Git Actions and Docker"
    ]
  },
  {
    "title": "Flask-based CMS (WordPress Alternative)",
    "period": "2024",
    "technologies": ["Flask", "React", "SQLite", "CLI"],
    "description": "Designed and implemented a CMS similar to WordPress using Flask and React.",
    "bullets": [
      "Customizable content management system",
      "CLI-based admin support",
      "Modern UI built with React + Tailwind"
    ]
  },
  {
    "title": "Data Ingestion & Reporting with Snowflake",
    "period": "2025",
    "technologies": ["Snowflake", "Python", "AWS", "Django"],
    "description": "End-to-end data pipeline and reporting solution for analytics using Snowflake.",
    "bullets": [
      "Python scripts for ingestion and transformation",
      "Snowflake as central data warehouse",
      "Django reporting and visualization dashboards"
    ]
  }
]


export default function Projects(){
  return (
    <section>
      <h2 className="text-2xl font-bold mb-6">Selected projects</h2>
      <div className="grid gap-6">
        {projects.map((p,i)=> (
          <article key={i} className="bg-white p-6 rounded-lg shadow-sm">
            <header className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold">{p.title}</h3>
              <span className="text-sm text-slate-500">{p.period}</span>
            </header>
            <ul className="list-disc pl-5 text-slate-700">
              {p.bullets.map((b,idx)=>(<li key={idx}>{b}</li>))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  )
}
