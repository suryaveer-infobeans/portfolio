import React from 'react'

export default function About(){
  return (
    <section className="prose max-w-none">
      <h2>About</h2>
      <p>Experienced Software Engineer focusing on backend systems, automation tools, and data pipelines using Python, Django, and Flask. Proficient in designing scalable web applications and REST APIs with a focus on clean architecture, modular code, and database operations including MySQL and Oracle. Skilled in Shell scripting and Linux command-line utilities for automation and log parsing.</p>
      <p>Currently transitioning to Data Engineering with hands-on experience building pipelines that use Snowflake and AWS services. Interested in senior backend or data engineering roles where I can design robust ingestion and analytics workflows.</p>
    </section>
  )
}
