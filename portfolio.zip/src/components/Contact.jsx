import React, {useState} from 'react'
import axios from 'axios'

export default function Contact(){
  const [form, setForm] = useState({name:'',email:'',message:''})
  const [status, setStatus] = useState('')

  const submit = async (e) => {
    e.preventDefault()
    setStatus('Sending...')
    try{
      await axios.post('/api/contact', form)
      setStatus('Message sent — thanks!')
      setForm({name:'',email:'',message:''})
    }catch(err){
      console.error(err)
      setStatus('Failed to send — try again.')
    }
  }

  return (
    <section className="max-w-2xl">
      <h2 className="text-2xl font-bold mb-4">Contact</h2>
      <form onSubmit={submit} className="grid gap-4">
        <input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your name" className="p-3 border rounded" />
        <input required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Email" className="p-3 border rounded" />
        <textarea required value={form.message} onChange={e=>setForm({...form,message:e.target.value})} placeholder="Message" className="p-3 border rounded h-36" />
        <button className="px-4 py-2 bg-slate-900 text-white rounded">Send message</button>
        <div className="text-sm text-slate-600">{status}</div>
      </form>
    </section>
  )
}
