import React from 'react'

export default function Hero(){
  return (
    <section className="grid md:grid-cols-2 gap-8 items-center">
      <div>
        <h1 className="text-4xl font-extrabold mb-4">Thakur Suryaveer Singh</h1>
        <p className="text-lg text-slate-700 mb-6">Senior Software Engineer with 10+ years building backend systems, automation tools, and data pipelines using Python, Django, Flask, and AWS. Transitioning to Data Engineering with a focus on Python and Snowflake.</p>
        <div className="flex gap-4">
          <a href="mailto:thakursuryaveersingh@gmail.com" className="px-4 py-2 bg-slate-900 text-white rounded">Get in touch</a>
          <a href="/projects" className="px-4 py-2 border border-slate-300 rounded">See projects</a>
        </div>
        <ul className="mt-6 grid grid-cols-2 gap-2 text-sm text-slate-600">
          <li>Python • Django • Flask</li>
          <li>AWS • S3 • Lambda</li>
          <li>MySQL • Oracle • DB Triggers</li>
          <li>CI/CD • Git Actions • Docker</li>
        </ul>
      </div>
      <div className="bg-white rounded-xl p-6 shadow-md">
        <h3 className="font-semibold mb-3">Quick facts</h3>
        <dl className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <dt className="text-slate-500">Experience</dt>
            <dd>10+ years</dd>
          </div>
          <div>
            <dt className="text-slate-500">Location</dt>
            <dd>Pune, India</dd>
          </div>
          <div>
            <dt className="text-slate-500">Role</dt>
            <dd>Senior Software Engineer</dd>
          </div>
          <div>
            <dt className="text-slate-500">Email</dt>
            <dd>thakursuryaveersingh@gmail.com</dd>
          </div>
        </dl>
      </div>
    </section>
  )
}
